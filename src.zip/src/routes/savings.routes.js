const express = require('express');
const router = express.Router();
const savingsController = require('../controllers/savingsController');
const { auth, adminAuth } = require('../middlewares/auth');
const { validateSavings } = require('../middlewares/validation');
const { body } = require('express-validator');

const validateTransaction = [
    body('amount')
        .isFloat({ min: 0.01 })
        .withMessage('Amount must be a positive number'),
    body('remarks')
        .optional()
        .isLength({ max: 500 })
        .withMessage('Remarks must not exceed 500 characters'),
    require('../middlewares/validation').handleValidationErrors
];

router.post('/', auth, adminAuth, validateSavings, savingsController.createSavingsAccount);
router.get('/', auth, savingsController.getAllSavingsAccounts);
router.get('/statistics', auth, adminAuth, savingsController.getSavingsStatistics);
router.get('/:id', auth, savingsController.getSavingsAccountById);
router.post('/:id/deposit', auth, adminAuth, validateTransaction, savingsController.deposit);
router.post('/:id/withdraw', auth, adminAuth, validateTransaction, savingsController.withdraw);
router.post('/:id/calculate-interest', auth, adminAuth, savingsController.calculateInterest);
router.put('/:id', auth, adminAuth, savingsController.updateSavingsAccount);

module.exports = router;
