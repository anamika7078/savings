const savingsService = require('../services/savingsService');
const logger = require('../config/logger');

class SavingsController {
    async createSavingsAccount(req, res) {
        try {
            const savings = await savingsService.createSavingsAccount(req.body);

            res.status(201).json({
                success: true,
                message: 'Savings account created successfully',
                data: savings
            });
        } catch (error) {
            logger.error('Create savings account controller error:', error);
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async getAllSavingsAccounts(req, res) {
        try {
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 10;
            const filters = {
                status: req.query.status,
                accountType: req.query.accountType
            };

            const result = await savingsService.getAllSavingsAccounts(page, limit, filters);

            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            logger.error('Get all savings accounts controller error:', error);
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }

    async getSavingsAccountById(req, res) {
        try {
            const { id } = req.params;
            const savings = await savingsService.getSavingsAccountById(id);

            res.json({
                success: true,
                data: savings
            });
        } catch (error) {
            logger.error('Get savings account by ID controller error:', error);
            res.status(404).json({
                success: false,
                message: error.message
            });
        }
    }

    async deposit(req, res) {
        try {
            const { id } = req.params;
            const { amount, remarks } = req.body;

            const result = await savingsService.deposit(id, amount, remarks);

            res.json({
                success: true,
                message: 'Deposit successful',
                data: result
            });
        } catch (error) {
            logger.error('Deposit controller error:', error);
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async withdraw(req, res) {
        try {
            const { id } = req.params;
            const { amount, remarks } = req.body;

            const result = await savingsService.withdraw(id, amount, remarks);

            res.json({
                success: true,
                message: 'Withdrawal successful',
                data: result
            });
        } catch (error) {
            logger.error('Withdrawal controller error:', error);
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async calculateInterest(req, res) {
        try {
            const { id } = req.params;
            const result = await savingsService.calculateInterest(id);

            res.json({
                success: true,
                message: 'Interest calculated successfully',
                data: result
            });
        } catch (error) {
            logger.error('Calculate interest controller error:', error);
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async getSavingsStatistics(req, res) {
        try {
            const statistics = await savingsService.getSavingsStatistics();

            res.json({
                success: true,
                data: statistics
            });
        } catch (error) {
            logger.error('Get savings statistics controller error:', error);
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }

    async updateSavingsAccount(req, res) {
        try {
            const { id } = req.params;
            const savings = await savingsService.updateSavingsAccount(id, req.body);

            res.json({
                success: true,
                message: 'Savings account updated successfully',
                data: savings
            });
        } catch (error) {
            logger.error('Update savings account controller error:', error);
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }
}

module.exports = new SavingsController();
