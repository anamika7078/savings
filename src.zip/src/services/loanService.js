const { Loan, Member, Repayment, Fine } = require('../models');
const { sequelize } = require('../models');
const logger = require('../config/logger');
const moment = require('moment');

class LoanService {
    calculateEMI(principal, rate, term) {
        const monthlyRate = rate / 12 / 100;
        const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, term) / (Math.pow(1 + monthlyRate, term) - 1);
        return Math.round(emi * 100) / 100;
    }

    calculateTotalAmount(principal, rate, term) {
        const emi = this.calculateEMI(principal, rate, term);
        return Math.round(emi * term * 100) / 100;
    }

    async createLoanApplication(loanData) {
        const transaction = await sequelize.transaction();

        try {
            const lastLoan = await Loan.findOne({
                order: [['id', 'DESC']],
                transaction
            });

            const loanNumber = lastLoan ? `LOAN${String(lastLoan.id + 1).padStart(4, '0')}` : 'LOAN0001';

            const emiAmount = this.calculateEMI(loanData.principalAmount, loanData.interestRate, loanData.loanTerm);
            const totalAmount = this.calculateTotalAmount(loanData.principalAmount, loanData.interestRate, loanData.loanTerm);

            const loan = await Loan.create({
                ...loanData,
                loanNumber,
                emiAmount,
                totalAmount,
                remainingAmount: totalAmount,
                applicationDate: new Date()
            }, { transaction });

            const repayments = [];
            let remainingPrincipal = parseFloat(loanData.principalAmount);
            const monthlyRate = parseFloat(loanData.interestRate) / 12 / 100;

            for (let i = 1; i <= loanData.loanTerm; i++) {
                const interestPayment = remainingPrincipal * monthlyRate;
                const principalPayment = emiAmount - interestPayment;
                remainingPrincipal -= principalPayment;

                const dueDate = moment().add(i, 'months').toDate();

                repayments.push({
                    loanId: loan.id,
                    memberId: loanData.memberId,
                    repaymentNumber: i,
                    amount: emiAmount,
                    principalAmount: principalPayment,
                    interestAmount: interestPayment,
                    dueDate: moment(dueDate).format('YYYY-MM-DD'),
                    status: 'pending'
                });
            }

            await Repayment.bulkCreate(repayments, { transaction });

            await loan.update({
                nextEmiDate: moment().add(1, 'months').toDate(),
                dueDate: moment().add(1, 'months').toDate(),
                maturityDate: moment().add(loanData.loanTerm, 'months').toDate()
            }, { transaction });

            await transaction.commit();

            logger.info(`New loan application created: ${loan.loanNumber}`);

            return loan;
        } catch (error) {
            await transaction.rollback();
            logger.error('Create loan application error:', error);
            throw error;
        }
    }

    async getAllLoans(page = 1, limit = 10, filters = {}) {
        try {
            const offset = (page - 1) * limit;
            const where = {};

            if (filters.status) {
                where.status = filters.status;
            }

            if (filters.memberId) {
                where.memberId = filters.memberId;
            }

            const { count, rows } = await Loan.findAndCountAll({
                where,
                include: [
                    {
                        model: Member,
                        as: 'member',
                        attributes: ['memberId', 'firstName', 'lastName', 'phone']
                    },
                    {
                        model: Repayment,
                        as: 'repayments',
                        attributes: ['repaymentNumber', 'amount', 'dueDate', 'status', 'paymentDate']
                    }
                ],
                limit,
                offset,
                order: [['createdAt', 'DESC']]
            });

            return {
                loans: rows,
                pagination: {
                    page,
                    limit,
                    total: count,
                    pages: Math.ceil(count / limit)
                }
            };
        } catch (error) {
            logger.error('Get all loans error:', error);
            throw error;
        }
    }

    async getLoanById(id) {
        try {
            const loan = await Loan.findByPk(id, {
                include: [
                    {
                        model: Member,
                        as: 'member'
                    },
                    {
                        model: Repayment,
                        as: 'repayments'
                    },
                    {
                        model: Fine,
                        as: 'fines'
                    }
                ]
            });

            if (!loan) {
                throw new Error('Loan not found');
            }

            return loan;
        } catch (error) {
            logger.error('Get loan by ID error:', error);
            throw error;
        }
    }

    async approveLoan(id) {
        const transaction = await sequelize.transaction();

        try {
            const loan = await Loan.findByPk(id, { transaction });

            if (!loan) {
                throw new Error('Loan not found');
            }

            if (loan.status !== 'pending') {
                throw new Error('Loan can only be approved from pending status');
            }

            await loan.update({
                status: 'approved',
                approvalDate: new Date()
            }, { transaction });

            await transaction.commit();

            logger.info(`Loan approved: ${loan.loanNumber}`);

            return loan;
        } catch (error) {
            await transaction.rollback();
            logger.error('Approve loan error:', error);
            throw error;
        }
    }

    async disburseLoan(id, disbursementDate = new Date()) {
        const transaction = await sequelize.transaction();

        try {
            const loan = await Loan.findByPk(id, { transaction });

            if (!loan) {
                throw new Error('Loan not found');
            }

            if (loan.status !== 'approved') {
                throw new Error('Loan can only be disbursed from approved status');
            }

            await loan.update({
                status: 'disbursed',
                disbursementDate,
                nextEmiDate: moment(disbursementDate).add(1, 'months').toDate()
            }, { transaction });

            await transaction.commit();

            logger.info(`Loan disbursed: ${loan.loanNumber}`);

            return loan;
        } catch (error) {
            await transaction.rollback();
            logger.error('Disburse loan error:', error);
            throw error;
        }
    }

    async makeRepayment(repaymentId, paymentMethod, transactionId) {
        const transaction = await sequelize.transaction();

        try {
            const repayment = await Repayment.findByPk(repaymentId, {
                include: [{ model: Loan, as: 'loan' }],
                transaction
            });

            if (!repayment) {
                throw new Error('Repayment not found');
            }

            if (repayment.status === 'paid') {
                throw new Error('Repayment already paid');
            }

            const today = moment();
            const dueDate = moment(repayment.dueDate);
            const daysLate = today.diff(dueDate, 'days');

            let lateFee = 0;
            if (daysLate > 0) {
                lateFee = Math.round(repayment.loan.emiAmount * 0.02 * Math.min(daysLate, 30));
            }

            await repayment.update({
                status: 'paid',
                paymentDate: today.toDate(),
                paymentMethod,
                transactionId,
                lateFee
            }, { transaction });

            const loan = repayment.loan;
            const newAmountPaid = parseFloat(loan.amountPaid) + parseFloat(repayment.amount) + lateFee;
            const newRemainingAmount = parseFloat(loan.totalAmount) - newAmountPaid;

            await loan.update({
                amountPaid: newAmountPaid,
                remainingAmount: newRemainingAmount,
                emiPaidCount: loan.emiPaidCount + 1,
                latePaymentCount: daysLate > 0 ? loan.latePaymentCount + 1 : loan.latePaymentCount
            }, { transaction });

            if (newRemainingAmount <= 0) {
                await loan.update({ status: 'completed' }, { transaction });
            } else {
                const nextRepayment = await Repayment.findOne({
                    where: {
                        loanId: loan.id,
                        status: 'pending'
                    },
                    order: [['repaymentNumber', 'ASC']],
                    transaction
                });

                if (nextRepayment) {
                    await loan.update({
                        nextEmiDate: nextRepayment.dueDate
                    }, { transaction });
                }
            }

            await transaction.commit();

            logger.info(`Repayment made for loan ${loan.loanNumber}: ${repayment.amount}`);

            return {
                repayment,
                loan,
                lateFee
            };
        } catch (error) {
            await transaction.rollback();
            logger.error('Make repayment error:', error);
            throw error;
        }
    }

    async getLoanStatistics() {
        try {
            const totalLoans = await Loan.count();
            const pendingLoans = await Loan.count({ where: { status: 'pending' } });
            const approvedLoans = await Loan.count({ where: { status: 'approved' } });
            const disbursedLoans = await Loan.count({ where: { status: 'disbursed' } });
            const activeLoans = await Loan.count({ where: { status: 'active' } });
            const completedLoans = await Loan.count({ where: { status: 'completed' } });
            const defaultedLoans = await Loan.count({ where: { status: 'defaulted' } });

            const totalDisbursed = await Loan.sum('principalAmount', {
                where: { status: ['disbursed', 'active', 'completed'] }
            });

            const totalRecovered = await Loan.sum('amountPaid', {
                where: { status: ['disbursed', 'active', 'completed'] }
            });

            const outstandingAmount = await Loan.sum('remainingAmount', {
                where: { status: ['disbursed', 'active'] }
            });

            return {
                totalLoans,
                pendingLoans,
                approvedLoans,
                disbursedLoans,
                activeLoans,
                completedLoans,
                defaultedLoans,
                totalDisbursed: totalDisbursed || 0,
                totalRecovered: totalRecovered || 0,
                outstandingAmount: outstandingAmount || 0
            };
        } catch (error) {
            logger.error('Get loan statistics error:', error);
            throw error;
        }
    }
}

module.exports = new LoanService();
