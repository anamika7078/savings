const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Loan = sequelize.define('Loan', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    memberId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Members',
            key: 'id'
        }
    },
    loanNumber: {
        type: DataTypes.STRING(20),
        allowNull: false,
        unique: true
    },
    principalAmount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false
    },
    interestRate: {
        type: DataTypes.DECIMAL(5, 2),
        allowNull: false,
        defaultValue: 10.00
    },
    loanTerm: {
        type: DataTypes.INTEGER,
        allowNull: false,
        comment: 'Loan term in months'
    },
    emiAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    totalAmount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false
    },
    amountPaid: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
        defaultValue: 0.00
    },
    remainingAmount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('pending', 'approved', 'disbursed', 'active', 'completed', 'defaulted'),
        allowNull: false,
        defaultValue: 'pending'
    },
    applicationDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    approvalDate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    disbursementDate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    dueDate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    maturityDate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    purpose: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    collateral: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    guarantor: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    nextEmiDate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    emiPaidCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    latePaymentCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    }
}, {
    indexes: [
        {
            unique: true,
            fields: ['loanNumber']
        },
        {
            fields: ['memberId']
        },
        {
            fields: ['status']
        },
        {
            fields: ['applicationDate']
        }
    ]
});

module.exports = Loan;
